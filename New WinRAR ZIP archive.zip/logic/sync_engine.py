import os
import shutil
from pathlib import Path
from typing import List, Dict, Any

# Third-party libraries
from loguru import logger

# Internal modules
from services.drive_client import DriveClient
from services.openai_client import OpenAIClient
from database.db_manager import DBManager
from config.settings import settings

class SyncEngine:
    """
    The main orchestrator responsible for synchronizing files between 
    Google Drive and OpenAI Vector Store.
    
    Implements a robust 'Delta Sync' strategy using MD5 checksums.
    """

    TEMP_DIR = Path("temp_data")

    def __init__(self):
        """
        Initializes the engine and its core service dependencies.
        """
        logger.info("Initializing Sync Engine...")
        
        # Initialize Service Connectors
        self.drive = DriveClient()
        self.openai = OpenAIClient()
        self.db = DBManager()

        # Ensure temp directory exists and is clean
        self._prepare_temp_dir()

    def _prepare_temp_dir(self):
        """
        Ensures the temporary download directory exists and is empty.
        """
        if self.TEMP_DIR.exists():
            shutil.rmtree(self.TEMP_DIR)
        self.TEMP_DIR.mkdir(parents=True, exist_ok=True)

    def start(self):
        """
        Main execution entry point.
        Orchestrates the full synchronization workflow.
        """
        logger.info("Starting synchronization cycle...")

        try:
            # 1. Setup OpenAI Infrastructure (Vector Store)
            vector_store_id = self.openai.ensure_vector_store()
            
            # 2. Fetch remote file list from Google Drive
            drive_files = self.drive.list_pdfs_in_folder()
            
            # 3. Filter files that need processing (New or Changed)
            files_to_process = self._get_files_to_process(drive_files)
            
            if not files_to_process:
                logger.success("System is up-to-date. No new files to sync.")
            else:
                logger.info(f"Identified {len(files_to_process)} files requiring synchronization.")
                self._process_file_batch(files_to_process, vector_store_id)

            # 4. Finalize Assistant Configuration (Update Instructions/Tools)
            # This ensures the assistant gets the latest "system_instructions.txt"
            # and is linked to the correct vector store.
            assistant_id = self.openai.ensure_assistant(vector_store_id)
            
            logger.success("Synchronization Cycle Completed Successfully.")

        except Exception as e:
            logger.critical(f"Synchronization failed due to critical error: {str(e)}")
            raise e
        finally:
            # Final cleanup of temp resources
            self._prepare_temp_dir()

    def _get_files_to_process(self, drive_files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Compares remote Drive files against the local database state.
        Returns a list of files that are either new or have a changed MD5 checksum.
        
        Args:
            drive_files: List of file objects from Google Drive API.
        
        Returns:
            List[Dict]: Subset of files needing upload.
        """
        processing_queue = []
        
        for file in drive_files:
            file_id = file['id']
            file_name = file['name']
            remote_checksum = file['md5Checksum']

            # Check DB state
            is_processed, stored_checksum = self.db.check_file_status(file_id)

            if not is_processed:
                logger.info(f"New file detected: {file_name}")
                processing_queue.append(file)
            elif stored_checksum != remote_checksum:
                logger.warning(f"File modified (checksum mismatch): {file_name}. Re-syncing.")
                processing_queue.append(file)
            else:
                # File is up-to-date, skip
                pass

        return processing_queue

    def _process_file_batch(self, files: List[Dict[str, Any]], vector_store_id: str):
        """
        Iterates through the processing queue.
        Downloads -> Uploads -> Updates DB for each file.
        
        Args:
            files: List of files to process.
            vector_store_id: ID of the target OpenAI Vector Store.
        """
        success_count = 0
        fail_count = 0

        for index, file in enumerate(files, 1):
            file_id = file['id']
            file_name = file['name']
            checksum = file['md5Checksum']

            logger.info(f"Processing {index}/{len(files)}: {file_name}")

            local_path = None
            try:
                # Step A: Download from Drive
                local_path = self.drive.download_file(
                    file_id=file_id, 
                    file_name=file_name, 
                    destination_dir=str(self.TEMP_DIR)
                )

                if not local_path:
                    raise ValueError("Download returned no path.")

                # Step B: Upload to OpenAI Vector Store
                upload_status = self.openai.upload_file_to_store(
                    file_path=local_path, 
                    vector_store_id=vector_store_id
                )

                # Step C: Update State in Database (Only on success)
                if upload_status:
                    self.db.mark_file_as_processed(
                        file_id=file_id, 
                        file_name=file_name, 
                        checksum=checksum
                    )
                    success_count += 1
                
            except Exception as e:
                fail_count += 1
                logger.error(f"Failed to process {file_name}: {str(e)}")
                # We continue to the next file even if one fails
                continue
            
            finally:
                # Step D: Immediate Cleanup (Crucial for disk space)
                if local_path and os.path.exists(local_path):
                    try:
                        os.remove(local_path)
                    except OSError:
                        pass

        logger.info(f"Batch Processing Summary: {success_count} Succeeded, {fail_count} Failed.")