import os
import io
from typing import List, Dict, Any, Optional
from pathlib import Path

# Third-party libraries
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
from googleapiclient.errors import HttpError
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from loguru import logger

# Internal modules
from config.settings import settings

class DriveClient:
    """
    A robust, enterprise-grade wrapper for the Google Drive API v3.
    Handles authentication, recursive file listing, and secure downloading.
    """

    SCOPES = ['https://www.googleapis.com/auth/drive.readonly']

    def __init__(self):
        """
        Initializes the Drive Client.
        Validates credentials existence before attempting connection.
        """
        self.creds = None
        self.service = None
        self._authenticate()

    def _authenticate(self):
        """
        Authenticates using Service Account credentials defined in settings.
        Fail-fast strategy: If credentials are bad, crash immediately with a clear log.
        """
        try:
            if not os.path.exists(settings.GOOGLE_CREDENTIALS_FILE):
                raise FileNotFoundError(f"Credentials file not found at: {settings.GOOGLE_CREDENTIALS_FILE}")

            logger.info("Authenticating with Google Drive API...")
            self.creds = service_account.Credentials.from_service_account_file(
                settings.GOOGLE_CREDENTIALS_FILE, 
                scopes=self.SCOPES
            )
            self.service = build('drive', 'v3', credentials=self.creds, cache_discovery=False)
            logger.success("Google Drive Authentication Successful.")

        except Exception as e:
            logger.critical(f"Failed to authenticate with Google Drive: {str(e)}")
            raise e

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        retry=retry_if_exception_type((HttpError, TimeoutError, ConnectionError)),
        reraise=True
    )
    def list_pdfs_in_folder(self, folder_id: str = None) -> List[Dict[str, Any]]:
        """
        Recursively finds all PDF files within the specified folder and its subfolders.
        
        Args:
            folder_id (str): The Google Drive Folder ID to start searching from. 
                             Defaults to settings.GOOGLE_DRIVE_FOLDER_ID.

        Returns:
            List[Dict]: A list of file objects containing 'id', 'name', 'md5Checksum'.
        """
        target_folder_id = folder_id or settings.GOOGLE_DRIVE_FOLDER_ID
        if not target_folder_id:
            logger.error("No Google Drive Folder ID provided in settings.")
            raise ValueError("GOOGLE_DRIVE_FOLDER_ID is missing.")

        all_pdfs = []
        logger.info(f"Starting recursive scan for PDFs in folder ID: {target_folder_id}")

        self._walk_folder_tree(target_folder_id, all_pdfs)
        
        logger.info(f"Scan complete. Found {len(all_pdfs)} PDF files in total.")
        return all_pdfs

    def _walk_folder_tree(self, folder_id: str, pdf_accumulator: List[Dict[str, Any]]):
        """
        Internal helper to recursively walk the folder tree.
        Separates 'folders' for traversal and 'files' for collection.
        """
        page_token = None
        
        while True:
            try:
                # Query: Not trashed AND (is folder OR is PDF) AND parent is current folder
                query = (
                    f"'{folder_id}' in parents and trashed = false and "
                    f"(mimeType = 'application/vnd.google-apps.folder' or mimeType = 'application/pdf')"
                )
                
                results = self.service.files().list(
                    q=query,
                    pageSize=1000,
                    fields="nextPageToken, files(id, name, mimeType, md5Checksum)",
                    pageToken=page_token
                ).execute()

                items = results.get('files', [])

                for item in items:
                    if item['mimeType'] == 'application/vnd.google-apps.folder':
                        # Recursive step: Dive into subfolder
                        # logger.debug(f"Found subfolder: {item['name']}. Scanning content...")
                        self._walk_folder_tree(item['id'], pdf_accumulator)
                    else:
                        # It is a PDF (based on query filter)
                        pdf_accumulator.append({
                            'id': item['id'],
                            'name': item['name'],
                            'md5Checksum': item.get('md5Checksum') # Crucial for sync logic
                        })

                page_token = results.get('nextPageToken')
                if not page_token:
                    break

            except HttpError as error:
                logger.error(f"An error occurred while scanning folder {folder_id}: {error}")
                raise error

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((HttpError, ConnectionError))
    )
    def download_file(self, file_id: str, file_name: str, destination_dir: str) -> Optional[str]:
        """
        Downloads a specific file from Google Drive to the local temp directory.
        Uses chunked download for memory efficiency with large PDFs.

        Args:
            file_id (str): The Google Drive File ID.
            file_name (str): The name of the file (used for saving).
            destination_dir (str): Local path to save the file.

        Returns:
            str: The full local path of the downloaded file.
        """
        try:
            request = self.service.files().get_media(fileId=file_id)
            
            # Sanitize filename to prevent OS errors
            safe_filename = "".join([c for c in file_name if c.isalpha() or c.isdigit() or c in " ._-"])
            file_path = os.path.join(destination_dir, safe_filename)

            # Ensure buffer is ready
            fh = io.FileIO(file_path, mode='wb')
            downloader = MediaIoBaseDownload(fh, request, chunksize=1024*1024) # 1MB chunks

            done = False
            while done is False:
                status, done = downloader.next_chunk()
                # optional: logger.debug(f"Download {int(status.progress() * 100)}% for {file_name}")

            logger.info(f"Successfully downloaded: {file_name} -> {file_path}")
            return file_path

        except HttpError as e:
            logger.error(f"Failed to download file {file_name} (ID: {file_id}): {e}")
            # Clean up partial file if exists
            if 'file_path' in locals() and os.path.exists(file_path):
                os.remove(file_path)
            raise e
        except Exception as e:
            logger.error(f"Unexpected error downloading {file_name}: {str(e)}")
            raise e